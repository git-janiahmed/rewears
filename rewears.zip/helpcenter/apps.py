from django.apps import AppConfig


class HelpcenterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'helpcenter'
