from django.contrib import admin
from .models import AwaitingUser

# Register your models here.
admin.site.register(AwaitingUser)
